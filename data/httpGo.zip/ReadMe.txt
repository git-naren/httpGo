https://www.appbrewery.co/courses/enrolled/851555

narendra437qis@gmail.com/app1234



https://github.com/londonappbrewery/Flutter-Course-Resources

https://codemagic.io/

https://flutter.dev/docs/get-started/install
https://www.javatpoint.com/flutter
https://www.tutorialspoint.com/flutter/index.htm



Accelerator
C:\Users\ravin\AppData\Local\Android\sdk\extras\intel\Hardware_Accelerated_Execution_Manager



Devlopment Test Framework
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

http://rest-assured.io/  in combination with Java
https://citrusframework.org/
https://sourceforge.net/p/htt/wiki/Home/ also simple
http://startrinity.com/HttpTester/HttpRestApiClientTester.aspx --> LoadTest Tool as well




Test case can be in XML or JSON

--> can have all cases as group in single file

--> or store group as folder

--> report needs to be stored in db

--> can do seq/parallel execution


beatsprodinstance.cb254omykb0m.ap-south-1.rds.amazonaws.com 3306
beatsprodapp/



Variables [can have description]
Global variables are project level settings
Group Level Settings variables settings
TC Level Settings 

env variables  ${env.} starts with env
global variables  ${global.} starts with global
normal variables  ${}

HTTP RESPONSE LEVEL VARIABLES
response.body
response.body_size
response.code
response.response_time (in milliseconds)

{{custom.url}}
{{env.api-key}}

EXTRACT VARIABLE will store data from json/xml/html into local variable


Assert Step
3 types of comparisons: string, numeric, and regular expression
is empty
is not empty
is less than
is less than or equal to
contains
does not contain
equals
does not equal
is greater than
is greater or equal to
is less than (numeric)
equals (numeric)
is greater than or equal to (numeric)
matches (regular expression)
does not match (regular expression)







API Check has 4 different types of variables:

Built-In variables are initialized at the beginning of the check before any steps have run. These variables remain constant within a run but will change between runs.
Request variables are updated after every request step.
Custom variables are created by the user.
Global variables that can be shared across checks.
https://help.rigor.com/hc/en-us/articles/115004744608-API-Check-Variables

https://help.rigor.com/hc/en-us/articles/115004952508-API-Check-Overview --> PPT download






https://tutorialedge.net/golang/parsing-json-with-golang/
https://tutorialedge.net/golang/parsing-xml-with-golang/

https://tutorialedge.net/golang/go-face-recognition-tutorial-part-one/ --> setup face recognition

https://tutorialedge.net/golang/go-ticker-tutorial/ --> schedule

https://godoc.org/github.com/stretchr/testify/assert

https://www.thepolyglotdeveloper.com/2017/03/parse-xml-data-in-a-golang-application/  --> oth json and xml unmarshal togeter

<testcase>
	<variables>
		<node>UAT</node>
	</variables>
	<teststeps>
		<step type="http" name="">
			<method><method>
			<url></url>
			<header></header>
			<body></body>
			<body_from_file></body_from_file>
			<expect>
				<status>200</status>
				<status>200</status>
			</expect>
		</step>
		<step>			
		</step>
		<step>			
		</step>
		<step>			
		</step>	
	</teststeps>
</testcase>

{
	variables: {
		"node": "UAT"
	},
	teststeps:[
		{
			"type": "http",
			"name": "id_1",
			"method": "",
			"url": "",
			"headers":[
				"name": "val"
			],
			"parameters":[
				"name": "val"
			],
			"body": "file@1234.txt"
			"expect": [
			]
		},
		{
		}	
	]
}