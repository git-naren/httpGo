package main

import (
	"time"
	"net/http"
	"github.com/gorilla/mux"
)

type Route struct {
	Name        string
	Method      string
	Pattern     string
	HandlerFunc http.HandlerFunc
}

type Routes []Route

var routes = Routes{	
	Route{
		"createTestProject",
		"POST",
		API_BASE_PATH+"/projects/create",
		createTestProject,
	},
	Route{
		"createTestGroup",
		"POST",
		API_BASE_PATH+"/projects/{project}/groups/create",
		createTestGroup,
	},
	Route{
		"createTestCase",
		"POST",
		API_BASE_PATH+"/projects/{project/groups/{group}/testcases/create",
		createTestCase,
	},
	Route{
		"listProjects",
		"GET",
		API_BASE_PATH+"/projects",
		listProjects,
	},
	Route{
		"getProjectDetails",
		"GET",
		API_BASE_PATH+"/projects/{project}",
		getProjectDetails,
	},
	Route{
		"listGroups",
		"GET",
		API_BASE_PATH+"/projects/{project}/groups",
		listGroups,
	},
	Route{
		"getGroupDetails",
		"GET",
		API_BASE_PATH+"/projects/{project}/groups/{group}",
		getGroupDetails,
	},
	Route{
		"listTestCases",
		"GET",
		API_BASE_PATH+"/projects/{project}/groups/{group}/testcases",
		listTestCases,
	},
	Route{
		"getTestCaseDetails",
		"GET",
		API_BASE_PATH+"/projects/{project}/groups/{group}/testcases/{testcase}",
		getTestCaseDetails,
	},
	Route{
		"getTestStatus",
		"GET",
		API_BASE_PATH+"/test/status/{identifier}",
		getTestStatus,
	},	
	Route{
		"triggerTest",
		"POST",
		API_BASE_PATH+"/test/run",
		triggerTest,
	},
	Route{
		"getProjectReports",
		"GET",
		API_BASE_PATH+"/projects/{project}/reports",
		getProjectReports,
	},
	Route{
		"getTestReport",
		"GET",
		API_BASE_PATH+"/test/report/{identifier}",
		getTestReport,
	},
	Route{
		"getProjectsTree",
		"GET",
		API_BASE_PATH+"/projectstree/{treemode}",
		getProjectsTree,
	},
}

func WebRouter() *mux.Router {
	
	LogInfo.Println("Creating new WebRouter")

	router := mux.NewRouter().StrictSlash(true)

	for _, route := range routes {
		LogInfo.Println("Adding route", route)

		var handler http.Handler
		handler = route.HandlerFunc
		handler = LogWebRequest(handler, route.Name)

		router.Methods(route.Method).Path(route.Pattern).Name(route.Name).Handler(handler)
	}

	router.HandleFunc("/", homePage)
	router.PathPrefix(API_BASE_PATH+"/web/").Handler(http.StripPrefix(API_BASE_PATH+"/web/", http.FileServer(http.Dir("./web"))))

	return router
}

func LogWebRequest(inner http.Handler, name string) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()

		inner.ServeHTTP(w, r)

		LogInfo.Printf("[API] [%s] %s  %s  %s", name, r.Method,	r.RequestURI, time.Since(start))
	})
}
