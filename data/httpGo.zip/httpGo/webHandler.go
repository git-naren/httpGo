package main

import (
    "fmt"
    "net/http"
    "io/ioutil"    
    "encoding/json"
    "github.com/gorilla/mux"
)

func homePage(w http.ResponseWriter, r *http.Request) {
	LogInfo.Println("Enter homePage, Redirecting to "+ WEB_UI_DEFAULT_PATH)
	http.Redirect(w, r, WEB_UI_DEFAULT_PATH, http.StatusSeeOther)
}

func listProjects(w http.ResponseWriter, r *http.Request) {
	LogInfo.Println("[API] Enter listProjects")
	var response TestInfoResponse
	response.Status = SUCCESS
	response.Message = SUCCESS_MSG

	var projects []string
	status := getFoldersInPath(&projects, PROJECT_ROOT_PATH, false)
	conditionalLogger(status, "[API] Listing projects operation success" , "[API] Listing projects failed")
	if !status {
		response.Status = ERROR
		response.Message = ERROR_MSG
	}
	
	response.Data = projects
	LogInfo.Println("[API] Return listProjects response", response)

	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)	
}

func listGroups(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter listGroups")
	project := mux.Vars(r)["project"]

	rootPath := PROJECT_ROOT_PATH + project	
	LogInfo.Println("[API] List all groups from the project path "+rootPath)

	var response TestInfoResponse
	response.Status = SUCCESS
	response.Message = SUCCESS_MSG

	var groups []string
	status := getFoldersInPath(&groups, rootPath, false)
	conditionalLogger(status, "[API] Listing test groups operation success" , "[API] Listing test groups failed for project "+project)
	if !status {
		response.Status = ERROR
		response.Message = ERROR_MSG
	}
	
	response.Data = groups
	LogInfo.Println("[API] Return listProjects response", response)

	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)
}

func listTestCases(w http.ResponseWriter, r *http.Request) {
	LogInfo.Println("[API] Enter listTestCases")
	project := mux.Vars(r)["project"]
	group := mux.Vars(r)["group"]

	rootPath := PROJECT_ROOT_PATH + project + "/" + group
	LogInfo.Println("[API] List all test cases from the project group path "+rootPath)

	var response TestInfoResponse
	response.Status = SUCCESS
	response.Message = SUCCESS_MSG

	var testCases []string
	status := getFilesInPath(&testCases, rootPath, false, ".xml", true)
	conditionalLogger(status, "[API] Listing test cases operation success" , "[API] Listing test cases failed for project "+project+", group "+group)
	if !status {
		response.Status = ERROR
		response.Message = ERROR_MSG
	}
		
	response.Data = testCases
	LogInfo.Println("[API] Return listProjects response", response)

	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)	
}

func getProjectReports(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter getProjectReports")

	project := mux.Vars(r)["project"]

	rootPath := PROJECT_ROOT_PATH + project + REPORTS_LOCATION	
	LogInfo.Println("[API] List reports from the project path "+rootPath)

	var response TestInfoResponse
	response.Status = SUCCESS
	response.Message = SUCCESS_MSG

	var reports []ReportFolder
	status := getFoldersInPathOrderByTime(&reports, rootPath)
	conditionalLogger(status, "[API] Listing test reports operation success" , "[API] Listing test reports failed for project "+project)
	if !status {
		response.Status = ERROR
		response.Message = ERROR_MSG
	}
	
	response.Reports = reports
	LogInfo.Println("[API] Return getProjectReports response", response)

	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)
	
}

func getProjectDetails(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter getProjectDetails")
	
}

func getGroupDetails(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter getGroupDetails")
	
}

func getTestCaseDetails(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter getTestCaseDetails")
	
}

func createTestProject(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter createTestProject")
	
}

func createTestGroup(w http.ResponseWriter, r *http.Request) {
	LogInfo.Println("[API] Enter createTestGroup")
	
}

func createTestCase(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter createTestCase")
	
}

func triggerTest(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter scheduleTest")

	reqBody, err := ioutil.ReadAll(r.Body)
	if err != nil {
		LogWarn.Println("Trigger test failed, as read body failed", err)
		fmt.Fprintf(w, "Trigger test failed, as read body failed")		
	}
	
	var request TestRunRequest
	json.Unmarshal(reqBody, &request)

	LogInfo.Println("[API] Trigger test", request)
	
	//Call to runner
	response := processTestRequest(request.Project, request.Group, request.TestCase)   

	LogInfo.Println("[API] Return triggerTest response", response)
	
	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)
}

func getTestStatus(w http.ResponseWriter, r *http.Request) {
	LogInfo.Println("[API] Enter getTestStatus")
	identifier := mux.Vars(r)["identifier"]

	//json.NewEncoder(w).Encode(singleEvent)

	/*for _, singleEvent := range events {
		if singleEvent.ID == eventID {
			json.NewEncoder(w).Encode(singleEvent)
		}
	}*/
	fmt.Fprintf(w, "OK!  "+identifier)
}

func getTestReport(w http.ResponseWriter, r *http.Request) {
	LogInfo.Println("[API] Enter getTestReport")
	identifier := mux.Vars(r)["identifier"]

	//json.NewEncoder(w).Encode(singleEvent)

	/*for _, singleEvent := range events {
		if singleEvent.ID == eventID {
			json.NewEncoder(w).Encode(singleEvent)
		}
	}*/
	fmt.Fprintf(w, "OK!  "+identifier)
}

func getProjectsTree(w http.ResponseWriter, r *http.Request) {	
	LogInfo.Println("[API] Enter getProjectsTree")

	includeSteps := false

	treemode := mux.Vars(r)["treemode"]
	if (treemode=="complete") {
		includeSteps = true
	}

	LogInfo.Println("[API] List reports from the project path "+PROJECT_ROOT_PATH+ ", treemode: "+treemode)

	var response TestInfoResponse
	response.Status = SUCCESS
	response.Message = SUCCESS_MSG

	prepareTestProjects(PROJECT_ROOT_PATH, includeSteps, &response)

	LogInfo.Println("[API] Return getProjectsTree response", response)

	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)
	
}