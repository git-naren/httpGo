package main

import (
	"fmt"
	"bytes"
	"syscall"
	"strings"
	"os/exec"
)

func RunCommand(command string) (bool, error, string) {
	LogInfo.Println("RunCommand =>", command)

	cmdArgs := strings.Fields(command)	

	cmd := exec.Command(cmdArgs[0], cmdArgs[1:]...)
	stdoutBuf := &bytes.Buffer{}
	cmd.Stdout = stdoutBuf

	err := cmd.Run();
	if err != nil {		
		LogError.Println("Failed to run command", err)
		return false, err, ""
	}

	waitStatus := cmd.ProcessState.Sys().(syscall.WaitStatus)
	//waitStatus.ExitStatus() //0 success 1,2 fail
	LogInfo.Printf("ExitStatus: %s\n", []byte(fmt.Sprintf("%d", waitStatus.ExitStatus())))

	return true, nil, strings.TrimSuffix(stdoutBuf.String(), "\n")
}

func runStepExecutor(cm Config, step *TestStep) { 
	TID := cm[TEST_RUN_ID]
	LogInfo.Println(TID, "Enter runStepExecutor "+ step.Description)

	step.Status = true

	for i := 0; i < len(step.Commands); i++ {	
		status, exitError, output := RunCommand(replace_vars_data(cm, step.Commands[i].Command))
		LogInfo.Println(TID, "RUN RESPONSE <=", status, step.Commands[i].Command, output)
		cm[PARAM_RUN_STATUS] += conditionalString(status, "true , ", "false , ")
		cm[PARAM_RUN_OUTPUT] += ("\n"+output)	
		if !status { 			
			LogWarn.Println(TID, "Run command failed", exitError)
			if step.Commands[i].Mandatory {
				step.Status = false
				step.Message = "Mandatory command execution failed"
				LogError.Println(TID, step.Message)	
				break;
			}
		}		
	}	

	if step.Status {
		for i := 0; i < len(step.Extracts); i++ {	
			status, err := doVariableExtraction(cm, step.Extracts[i])
			if !status {
				LogWarn.Println(TID, "Variable extraction failed", err)
				if step.Extracts[i].Mandatory {
					step.Status = false
					step.Message = "Failed to extract mandatory variable "+step.Extracts[i].Name
					LogError.Println(TID, step.Message)						
					break;
				}			
			}			
		}
	}

	if step.Status {
		for j := 0; j < len(step.Expects); j++ {	
			if pNameVal, found := cm[step.Expects[j].Name]; found {
				status, err := doValidation(pNameVal, step.Expects[j].Check, replace_vars_data(cm, step.Expects[j].Value), step.Expects[j].ErrMsg)
				if !status {
					LogWarn.Println(TID, "Failed to validate parameter "+step.Expects[j].Name, err)
					if !step.Expects[j].Optional {
						step.Status = false
						step.Message = "Failed to validate parameter "+step.Expects[j].Name
						LogError.Println(TID, step.Message)						
						break;
					}
				}	    
			} else if !step.Expects[j].Optional {							 				
				step.Status = false
				step.Message = "Failed to validate parameter "+step.Expects[j].Name+", as it's not found"
				LogError.Println(TID, step.Message)	
				break;
			}
		}
	}

	LogInfo.Println(TID, "runStepExecutor result", step.Status)

	step.LogData = cm[PARAM_RUN_OUTPUT]

	delete(cm, PARAM_RUN_STATUS)
	delete(cm, PARAM_RUN_OUTPUT)	
}
