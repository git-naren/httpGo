package main

import (
	//"fmt"
	"strings"
	"strconv"
	"context"
	"log"
	"time"
	"github.com/chromedp/chromedp"
)

func browserStepExecutor(cm Config, step *TestStep) { 
	TID := cm[TEST_RUN_ID]
	LogInfo.Println(TID, "Enter browserStepExecutor "+ step.Description)

	allocOpts  := chromedp.DefaultExecAllocatorOptions[:]
	opts := strings.Split(step.Options, ";")	
	for _, option := range opts {	    
	    optNameVal := strings.Split(option, "=")
	    if (optNameVal[1] == "true") {
		allocOpts = append(allocOpts, chromedp.Flag(optNameVal[0], true))
	    } else  if (optNameVal[1] == "false") {
		allocOpts = append(allocOpts, chromedp.Flag(optNameVal[0], false))
	    } else {
		allocOpts = append(allocOpts, chromedp.Flag(optNameVal[0], optNameVal[1] ))
	    }
	}

	allocCtx, cancel := chromedp.NewExecAllocator(context.Background(), allocOpts...)
	defer cancel()
	
	ctx, cancel := chromedp.NewContext(allocCtx, chromedp.WithLogf(log.Printf))
	defer cancel()

	step.Status = true
	for i := 0; i < len(step.Functions); i++ {			
		funName := strings.ToLower( step.Functions[i].Name)
		funInput := replace_vars_data(cm, step.Functions[i].InputData)
		
		status := true
		var err error = nil
		if funName == "navigate" {			
			err = chromedp.Run(ctx, chromedp.Navigate(funInput))			
		} else if funName == "navigateback" {
			err = chromedp.Run(ctx, chromedp.NavigateBack())
		} else if funName == "navigateforward" {
			err = chromedp.Run(ctx, chromedp.NavigateForward())
		} else if funName == "navigatetohistoryentry" {
			funInputIntVal, convErr := strconv.ParseInt(funInput, 10, 64)
			if convErr != nil {
				LogWarn.Println(TID, "Failed to convertto int from funInput "+funInput)
				status = false
			}
			err = chromedp.Run(ctx, chromedp.NavigateToHistoryEntry(funInputIntVal))
		} else if funName == "reload" {
			err = chromedp.Run(ctx, chromedp.Reload())
		} else if funName == "waitvisible" {
			err = chromedp.Run(ctx, chromedp.WaitVisible(funInput, chromedp.ByID))
		} else if funName == "KeyEvent" {
			
		} else if funName == "SendKeys" {
			
		} else if funName == "Click" {
			chromedp.Run(ctx, chromedp.Click(funInput))			
		} else if funName == "Clear" {
			chromedp.Run(ctx, chromedp.Clear(funInput))			
		} else if funName == "Sleep" {
			chromedp.Run(ctx, chromedp.Sleep(1 * time.Second))			
		} else {
			LogWarn.Println(TID, "Unsupported function "+funName)
			status = false
		}	

		if err != nil {
			log.Fatal(err)
			status = false
		}

		if !status { 			
			LogWarn.Println(TID, "Run browser function failed")
			if step.Functions[i].Mandatory {
				step.Status = false
				step.Message = "Mandatory browser function execution failed"
				LogError.Println(TID, step.Message)	
				break;
			}
		}		
	}	

	if step.Status {
		for i := 0; i < len(step.Extracts); i++ {	
			status, err := doVariableExtraction(cm, step.Extracts[i])
			if !status {
				LogWarn.Println(TID, "Variable extraction failed", err)
				if step.Extracts[i].Mandatory {
					step.Status = false
					step.Message = "Failed to extract mandatory variable "+step.Extracts[i].Name
					LogError.Println(TID, step.Message)						
					break;
				}			
			}			
		}
	}

	if step.Status {
		for j := 0; j < len(step.Expects); j++ {	
			if pNameVal, found := cm[step.Expects[j].Name]; found {
				status, err := doValidation(pNameVal, step.Expects[j].Check, replace_vars_data(cm, step.Expects[j].Value), step.Expects[j].ErrMsg)
				if !status {
					LogWarn.Println(TID, "Failed to validate parameter "+step.Expects[j].Name, err)
					if !step.Expects[j].Optional {
						step.Status = false
						step.Message = "Failed to validate parameter "+step.Expects[j].Name
						LogError.Println(TID, step.Message)						
						break;
					}
				}	    
			} else if !step.Expects[j].Optional {							 				
				step.Status = false
				step.Message = "Failed to validate parameter "+step.Expects[j].Name+", as it's not found"
				LogError.Println(TID, step.Message)	
				break;
			}
		}
	}

	LogInfo.Println(TID, "browserStepExecutor result", step.Status)

	//step.LogData = cm[PARAM_RUN_OUTPUT]

	//delete(cm, PARAM_BROWSER_STATUS)
	//delete(cm, PARAM_RUN_OUTPUT)	
}
